<?php

require_once dirname(__FILE__).'/general.inc.php';

require_once dirname(__FILE__).'/class/sys/status.inc.php';
require_once dirname(__FILE__).'/class/sys/sys.inc.php';
require_once dirname(__FILE__).'/class/sys/users.inc.php';
require_once dirname(__FILE__).'/class/sys/menus.inc.php';


?>
